# Handoff: Lauf-teilen Share-Card

## Overview
Eine teilbare Lauf-Grafik für Runners Conquer („ConqRun"). Beim Teilen eines Laufs sieht
der Nutzer seine **Lauf-Daten** (Zeit, Pace, Distanz) über dem **eroberten Gebiet** — der
gelaufenen Strecke, als isometrisches, neon-leuchtendes 3D-Territorium mit Flagge dargestellt.
Die Karte ist **vollständig transparent**, sodass der Nutzer einen eigenen Hintergrund wählt
(z.B. ein Foto aus der Galerie). Die **Akzentfarbe ist frei wählbar**.

## About the Design Files
Die Dateien in diesem Bundle sind **Design-Referenzen, erstellt in HTML** — ein Prototyp, der
Aussehen und Verhalten zeigt, **kein** produktiver Code zum 1:1-Kopieren. Aufgabe ist, dieses
Design in der bestehenden Umgebung der Ziel-App nachzubauen (die App ist ein
self-contained HTML/JS-PWA mit Leaflet/Turf/Chart.js — siehe `maxst0297-ux/run-conquer`),
mit deren etablierten Mustern und Bibliotheken.

**Ausnahme:** `territory.js` ist bereits **produktionsreifes Vanilla-JS** und kann direkt
übernommen werden — es ist der Kern-Renderer für das Gebiet.

## Fidelity
**High-fidelity (hifi).** Finale Farben, Typografie, Abstände und der Gebiets-Render sind
final. Pixelgenau nachbauen. Einzige bewusst generische Stelle: die Demo-Gebietsform — im
Produktivbetrieb kommt sie aus echten GPS-Daten (siehe unten).

---

## Screen: Share-Card

**Purpose:** Ergebnis eines Laufs teilbar machen; Stolz/Status („own the world") zeigen.

**Layout:** Eine vertikale Flex-Spalte (`flex-direction: column`), transparenter Hintergrund.
Design-Breite **1080 px**, Höhe je nach Format (Quadrat 1080, Hochkant 1350, Story 1920).
Padding `74px 64px 60px`. Vier Blöcke von oben nach unten:

1. **Tagline** (oben, zentriert)
2. **Stat-Reihe** (3 Spalten mit Trennern)
3. **Hero / Gebiet** (`flex: 1`, füllt den Mittelraum)
4. **Logo** (unten, zentriert)

### Components

**1 · Tagline** — `.rc-tagline`
- Text: `RUN CONQUER. OWN THE WORLD.`
- Font: Poppins 600, **22px**, `letter-spacing: 8px`, `text-transform: uppercase`
- Farbe: `rgba(255,255,255,.82)`, `text-shadow: 0 2px 10px rgba(0,0,0,.5)`
- zentriert

**2 · Stat-Reihe** — `.rc-stats`
- `display: grid; grid-template-columns: 1fr 1px 1fr 1px 1fr; align-items: center;`
- `margin-top: 54px`
- Pro Stat (`.rc-stat`, zentriert):
  - Icon (Font Awesome 6.4): **34px**, `rgba(255,255,255,.92)`, `drop-shadow(0 2px 8px rgba(0,0,0,.45))`
    - Zeit: `fa-regular fa-clock` · Pace: `fa-solid fa-gauge-high` · km: `fa-solid fa-route`
  - Wert `.v`: **Bebas Neue**, **84px**, `line-height:.92`, `letter-spacing:1px`, Farbe `#fff`,
    `margin-top:18px`, `text-shadow:0 3px 16px rgba(0,0,0,.55)`
  - Label `.l`: Poppins 600, **19px**, `letter-spacing:3px`, uppercase, `rgba(255,255,255,.62)`, `margin-top:12px`
- Trenner `.rc-div`: 1px breit, 92px hoch, `linear-gradient(180deg, transparent, rgba(255,255,255,.22), transparent)`
- Inhalt (Platzhalter): `28:45` / Zeit · `6:12` / Pace / km · `5,32` / km

**3 · Hero / Gebiet** — `.rc-hero` (`flex:1`), SVG via `RC.renderTerritory()` (siehe `territory.js`)
- Isometrisches, extrudiertes 3D-Polygon = das eroberte Gebiet / die gelaufene Strecke
- Leuchtende Akzent-Kontur (mehrlagig: Glow-Filter + weiße 2px Innenlinie + 3.5px Akzentlinie)
- Halbtransparente dunkle Füllung (`rgba(8,14,12,.42)`→`rgba(4,8,7,.66)`) → Foto schimmert durch
- Schwache Straßen-Textur im Inneren (geclippt), Boden-Halo in Akzentfarbe
- Weiße **Flagge** aufrecht im Schwerpunkt, mit Bodenschatten
- Parameter: `accent`, `glow` (0–1.6), `showMap`, `showFlag`

**4 · Logo** — `.rc-logo`
- `.mark` Text `RQ`: Bebas Neue **96px**, `letter-spacing:4px`,
  Verlaufs-Text `linear-gradient(180deg,#fff 0%,#fff 38%,#b9bcc4 100%)` via `background-clip:text`
- `.underline`: 92×5px, `border-radius:3px`, `background: var(--accent)`, `box-shadow:0 0 18px var(--accent)`

---

## Interactions & Behavior
Die Karte ist eine statische Export-Grafik — keine Laufzeit-Interaktion im geteilten Bild.
Im **Editor** (vor dem Teilen) steuerbar:
- **Akzentfarbe** — frei wählbar (Hex). Setzt `--accent` am Card-Element **und** den `accent`-Parameter von `renderTerritory()`.
- **Format** — Quadrat 1080×1080 / Hochkant 1080×1350 / Story 1080×1920.
- **Glow-Intensität**, **Straßen-Karte an/aus**, **Flagge an/aus**.
- **Lesbarkeits-Verlauf** (`.rc-scrim`, default aus) — dezenter dunkler Verlauf oben/unten für helle/unruhige Fotos.
- **Hintergrund** — eigenes Foto aus der Galerie (liegt unter der transparenten Karte).

Entrance-Animationen (optional, falls im Editor gewünscht): Design-System nutzt
`cubic-bezier(.34,1.15,.64,1)`; Zähler ticken hoch, GPS-Spur zeichnet via `stroke-dashoffset`.

## State Management
- `accent: string` (Hex)
- `format: 'Quadrat'|'Hochkant'|'Story'`
- `glow: number` (0–1.6), `showMap: bool`, `showFlag: bool`, `scrim: bool`
- `stats: { time, pace, dist }` (aus dem Lauf)
- `routeBoundary: [[x,y],…]` — Grenz-Polygon des eroberten Gebiets (aus GPS, siehe unten)
- `backgroundImage: File|url` — Galerie-Foto

## Gebiet aus echten GPS-Daten
```js
const svg = RC.renderTerritory({
  points: boundaryXY,   // [[x,y], …] geschlossener Ring; Wicklung egal, auto-zentriert/skaliert
  accent: userColor, width: 1080, height: 900,
  glow: 1, showMap: true, showFlag: true
});
heroEl.innerHTML = svg;
```
Route-`latlng` → in lokale Meter projizieren (equirektangulär reicht für einen Lauf) →
**umschlossene Fläche** als Ring übergeben. Ohne `points` erzeugt `RC.generateTerritory(seed)`
eine stabile Demo-Form.

## Export als transparentes PNG
Karte über transparentem Canvas rendern (`html-to-image`, `backgroundColor:'transparent'`).
Beim Teilen: Galerie-Foto als unterste Ebene, Karte darüber, zusammen exportieren.

---

## Design Tokens (aus dem Runners-Conquer-System)
**Farben**
- Akzent default (episch/Purple): `#9B5DE5`
- Frei wählbare Team-Farben: Lime `#E6FF55` · Rot `#FF4D6D` · Cyan `#00D4FF` · Gold `#FFD700` · Orange `#FF9F1C` · Grün `#10B981`
- Text auf der Karte: `#fff` mit Schatten (für Lesbarkeit auf beliebigem Foto)
- Gebiets-Füllung: `rgba(8,14,12,.42)` → `rgba(4,8,7,.66)`

**Typografie**
- Display/Zahlen: **Bebas Neue** (uppercase, getrackt)
- Body/Labels: **Poppins** 400–800
- Skala hier: Tagline 22/8px · Stat-Icon 34 · Stat-Wert 84 · Stat-Label 19/3px · Logo 96/4px

**Geometrie/Effekte**
- Stat-Trenner-Höhe 92px · Logo-Unterstrich 92×5px r3
- Glow `box-shadow: 0 0 18px var(--accent)`
- Easing `cubic-bezier(.34,1.15,.64,1)`

## Assets
- **Icons:** Font Awesome 6.4 (CDN) — `fa-clock`, `fa-gauge-high`, `fa-route`
- **Fonts:** Bebas Neue + Poppins (Google Fonts) — siehe `colors_and_type.css`
- **Logo:** Wortmarke „RQ" als getypter Bebas-Neue-Schriftzug (kein Bild-Asset nötig)
- Keine Foto-Assets im Bundle — der Hintergrund kommt vom Nutzer.

## Files
| Datei | Inhalt |
|---|---|
| `Lauf teilen - Share Card.html` | Vollständiger Prototyp + Editor (Tweaks). Referenz für Markup, CSS, Layout. |
| `territory.js` | **Produktionsreifer** Vanilla-Renderer für das Gebiet. Direkt übernehmbar. |
| `tweaks-panel.jsx` | Editor-Steuerung (nur für die Vorschau; nicht für Produktion nötig). |
| `colors_and_type.css` | Design-Tokens (Farben, Typo) des Runners-Conquer-Systems. |
| `preview-transparent.jpg` | Zielbild: Karte über transparentem (Schachbrett-)Hintergrund. |
| `preview-over-photo.jpg` | Zielbild: Karte über einem Foto/Verlauf — zeigt die Transparenz in Aktion. |
