// ============================================================
// Runners Conquer — REDESIGN · canvas mount
// One app · four areas, each on its own interactive phone.
// Same bottom nav everywhere: Karte · Start · Community · Profil
// ============================================================

function Phone({ initialView }) {
  return (
    <div className="rc-phone">
      <ConqApp initialView={initialView} />
    </div>
  );
}

function Caption({ tag, title, children }) {
  return (
    <div style={{ width: 360, marginTop: 22, fontFamily: 'var(--font-body)', color: '#3a352e' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 7 }}>
        <span style={{ fontFamily: 'var(--font-display)', letterSpacing: 1, fontSize: 13, color: '#0D3D2C',
          background: '#E6FF55', borderRadius: 6, padding: '2px 9px' }}>{tag}</span>
        <span style={{ fontFamily: 'var(--font-display)', letterSpacing: 1.5, fontSize: 21, color: '#1f2a23' }}>{title}</span>
      </div>
      <p style={{ margin: 0, fontSize: 13.5, lineHeight: 1.6, color: '#525249' }}>{children}</p>
    </div>
  );
}

function Board({ initialView, tag, title, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 8 }}>
      <Phone initialView={initialView} />
      <Caption tag={tag} title={title}>{children}</Caption>
    </div>
  );
}

/* Board for standalone parts that already render their own phone shell */
function MoreBoard({ screen, tag, title, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 8 }}>
      {screen}
      <Caption tag={tag} title={title}>{children}</Caption>
    </div>
  );
}

function Root() {
  return (
    <DesignCanvas>
      <DCSection id="app" title="ConqRun — eine App, vier klare Bereiche"
        subtitle="Einheitliche Navigation auf jedem Screen: Karte · Start · Community · Profil · tippe Tabs & START">
        <DCArtboard id="start" label="START" width={420} height={1010} style={{ background: 'transparent' }}>
          <Board initialView="start" tag="1" title="START">
            Zuhause & Aktivität in einem: großer START-Button mit Energie, Wochenziel mit
            7-Tage-Verlauf, drei Kernzahlen, die Quests als Belohnungskarten und die letzten
            Läufe — alles auf einen Blick.
          </Board>
        </DCArtboard>

        <DCArtboard id="karte" label="KARTE" width={420} height={1010} style={{ background: 'transparent' }}>
          <Board initialView="karte" tag="2" title="KARTE">
            Dein Revier als Vollbild-Karte: eroberte Gebiete, Rivalen, Wahrzeichen und dein
            GPS-Pfad mit Legende. Unten das Lauf-Dock — START, dann Live-Werte (km, Zeit,
            Pace, Puls).
          </Board>
        </DCArtboard>

        <DCArtboard id="community" label="COMMUNITY" width={420} height={1010} style={{ background: 'transparent' }}>
          <Board initialView="community" tag="3" title="COMMUNITY">
            Saison-Countdown, Live-Rangliste mit deiner eigenen Platzierung hervorgehoben,
            aktuelle News aus deinem Umfeld und Gebiete in der Nähe zum Angreifen.
          </Board>
        </DCArtboard>

        <DCArtboard id="profil" label="PROFIL" width={420} height={1010} style={{ background: 'transparent' }}>
          <Board initialView="profil" tag="4" title="PROFIL">
            Dein Läufer-Profil: Herrscher-Titel, Level-Fortschritt, Herrschaft (regierte
            Gebiete, verteidigt, Raids), Bestleistungen und freigeschaltete Erfolge.
          </Board>
        </DCArtboard>
      </DCSection>

      <DCSection id="more" title="Weitere Bestandteile — Zustände & Flows"
        subtitle="Die übrigen Teile der App, je als eigener Entwurf: Einstieg, Lauf-Ende, ein Gebiet im Detail und die Einstellungen">
        <DCArtboard id="onboarding" label="ONBOARDING" width={420} height={1010} style={{ background: 'transparent' }}>
          <MoreBoard screen={<OnboardingScreen />} tag="5" title="ONBOARDING">
            Der Einstieg: Konto neu anlegen oder anmelden. Spielername, Avatar und Team-Farbe
            in einer ruhigen Karte — tippe zwischen „Neu“ und „Anmelden“ und wähle Avatar &amp; Farbe.
          </MoreBoard>
        </DCArtboard>

        <DCArtboard id="summary" label="LAUF-ENDE" width={420} height={1010} style={{ background: 'transparent' }}>
          <MoreBoard screen={<RunSummaryScreen />} tag="6" title="LAUF-ZUSAMMENFASSUNG">
            Direkt nach STOP: gefeierter Erfolg „Gebiet erobert“, die gelaufene Route, vier
            Kernwerte, Splits pro Kilometer und der Fortschritt zum nächsten Herrscher-Tier.
          </MoreBoard>
        </DCArtboard>

        <DCArtboard id="territory" label="GEBIET" width={420} height={1010} style={{ background: 'transparent' }}>
          <MoreBoard screen={<TerritoryScreen />} tag="7" title="GEBIET-DETAIL">
            Ein Gebiet angetippt: Karte oben, Detail-Sheet unten — Seltenheit, wer herrscht,
            Fläche &amp; Verteidigungen, Bedrohungen in der Nähe. Tippe VERTEIDIGEN.
          </MoreBoard>
        </DCArtboard>

        <DCArtboard id="settings" label="EINSTELLUNGEN" width={420} height={1010} style={{ background: 'transparent' }}>
          <MoreBoard screen={<SettingsScreen />} tag="8" title="EINSTELLUNGEN">
            Aus der Hauptnavigation ausgelagert: Theme &amp; Team wechseln, Benachrichtigungen
            schalten und Konto verwalten. Tippe Themes, Teams und die Schalter.
          </MoreBoard>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Root />);
