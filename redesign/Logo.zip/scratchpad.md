# Runners Conquer — Redesign (interaktives App-Mockup)

Ziel des Nutzers: **nutzerfreundlicher & einfacher** im Aufbau, ohne Funktion zu verlieren.
3 Design-Richtungen zum Vergleichen, jede als **interaktives Phone** im Design-Canvas.

Visuelle Basis = bindend: Runners-Conquer-Tokens (`ds/colors_and_type.css`) + Komponenten-CSS
(`ds/kit.css`). Citrus-Theme (Deep Forest + Citrus Lime), Bebas Neue + Poppins, Font Awesome 6.4,
Conquest-Gold für Status. Sprache: Deutsch, du-Form.

## UX-Probleme im Original
- **5 Tabs** (Karte, Aktivität, Community, Profil, Menü) — eine zu viel; Menü/Settings gehört
  nicht in die Hauptnavigation.
- Sehr **dichte Stat-Karten** + viele konkurrierende Emoji/Zahlen → hohe kognitive Last.
- Kein klarer **Einstieg/Heute-Fokus**; die wichtigste Aktion (START) lebt nur auf der Karte.
- Wiederholte Infos über Screens verteilt.

## 3 Richtungen

### A · KLAR  (entrümpelt, ruhig)
- 4 Tabs: **Start · Karte · Community · Profil** — Settings als Zahnrad im Header.
- Neuer **Start-Hub**: Begrüßung, ein Hero mit großem START, ein Wochenziel, 3 Kernzahlen,
  max. 3 Tagesquests. Großzügiger Weißraum, Lime als echter Akzent (nicht überall).
- Beste Wahl für „einfach & übersichtlich“.

### B · REVIER  (Karte zuerst, immersiv)
- Karte ist die Startseite, voll-bleed. **Bottom-Sheet** (Peek → ausziehbar) bündelt START,
  Tageswerte und nächste Gebiete. Transparenter Overlay-Header.
- 3 Tabs + großer **zentraler START-FAB** in der Navigation.
- Minimale Chrome, Spiel-Atmosphäre.

### C · LIGA  (Status & Wettkampf nach vorne)
- Home **Liga**: dein Rang groß, Herrscher-Tier-Fortschritt, Saison-Countdown, Top-Rangliste,
  Quests als Belohnungskarten. Gold-Akzente prominent.
- 4 Tabs: **Liga · Karte · Aktivität · Profil**.
- Für Nutzer, die der Wettbewerb antreibt.

## Geteilte Screens (alle Richtungen, leicht pro Richtung getönt)
Karte (mit Lauf-Dock + Live-Ticker), Community/Rangliste, Profil, Aktivität.
Interaktiv: Tab-Wechsel, START → Live-Lauf-Ticker → STOP-Toast, Bottom-Sheet ziehen.
